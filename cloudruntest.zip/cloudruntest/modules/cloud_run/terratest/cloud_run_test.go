package test

import (
    "fmt"
    "strings"
    "testing"
    "time"

    "github.com/gruntwork-io/terratest/modules/gcp"
    "github.com/gruntwork-io/terratest/modules/random"
    "github.com/gruntwork-io/terratest/modules/terraform"
    test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
    "github.com/stretchr/testify/assert"
    "github.com/stretchr/testify/require"
)

// Test the Cloud Run module with basic configuration
func TestCloudRunBasicDeployment(t *testing.T) {
    t.Parallel()

    // Generate a unique service name for this test
    uniqueID := strings.ToLower(random.UniqueId())
    serviceName := fmt.Sprintf("test-cr-%s", uniqueID)

    // Get the project ID from environment or use default
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    // Define the test directory
    testDir := test_structure.CopyTerraformFolderToTemp(t, "../", "test")

    // Terraform options for the test
    terraformOptions := &terraform.Options{
        TerraformDir: testDir,
        Vars: map[string]interface{}{
            "project_id":   projectID,
            "service_name": serviceName,
            "location":     "us-central1",
            "env_vars": map[string]string{
                "TEST_RUN": "terratest",
                "TEST_ID":  uniqueID,
            },
            "invokers": []string{"allUsers"},
            "default_labels": map[string]string{
                "test":      "terratest",
                "test_id":   uniqueID,
                "temporary": "true",
            },
        },
        NoColor: true,
    }

    // Ensure cleanup
    defer terraform.Destroy(t, terraformOptions)

    // Deploy the Cloud Run service
    terraform.InitAndApply(t, terraformOptions)

    // Validate outputs
    serviceURL := terraform.Output(t, terraformOptions, "service_url")
    actualServiceName := terraform.Output(t, terraformOptions, "service_name")
    latestRevision := terraform.Output(t, terraformOptions, "latest_revision_name")
    validationStatus := terraform.Output(t, terraformOptions, "module_validation_status")

    // Basic assertions
    assert.NotEmpty(t, serviceURL, "Service URL should not be empty")
    assert.Equal(t, serviceName, actualServiceName, "Service name should match")
    assert.NotEmpty(t, latestRevision, "Latest revision should not be empty")
    assert.Equal(t, "PASSED", validationStatus, "Service should be ready")
    assert.Contains(t, serviceURL, "run.app", "Service URL should be a Cloud Run URL")
}

// Test Cloud Run with traffic splitting
func TestCloudRunTrafficSplitting(t *testing.T) {
    t.Parallel()

    uniqueID := strings.ToLower(random.UniqueId())
    serviceName := fmt.Sprintf("test-cr-traffic-%s", uniqueID)
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    testDir := test_structure.CopyTerraformFolderToTemp(t, "../", "test")

    // First deployment
    terraformOptions := &terraform.Options{
        TerraformDir: testDir,
        Vars: map[string]interface{}{
            "project_id":                projectID,
            "service_name":              serviceName,
            "location":                  "us-central1",
            "autogenerate_revision_name": false,
            "revision_name":             fmt.Sprintf("%s-001", serviceName),
            "env_vars": map[string]string{
                "VERSION": "1.0.0",
            },
        },
        NoColor: true,
    }

    defer terraform.Destroy(t, terraformOptions)

    // Initial deployment
    terraform.InitAndApply(t, terraformOptions)

    firstRevision := terraform.Output(t, terraformOptions, "latest_revision_name")
    require.NotEmpty(t, firstRevision)

    // Update with traffic split
    terraformOptions.Vars["revision_name"] = fmt.Sprintf("%s-002", serviceName)
    terraformOptions.Vars["env_vars"] = map[string]string{
        "VERSION": "2.0.0",
    }
    terraformOptions.Vars["traffic_config"] = []map[string]interface{}{
        {
            "percent":         50,
            "revision_name":   firstRevision,
            "latest_revision": false,
            "tag":            "v1",
        },
        {
            "percent":         50,
            "revision_name":   nil,
            "latest_revision": true,
            "tag":            "v2",
        },
    }

    // Apply the update
    terraform.Apply(t, terraformOptions)

    // Validate traffic configuration
    trafficStatusRaw := terraform.OutputJson(t, terraformOptions, "traffic_status")
    var trafficStatus []map[string]interface{}
    require.NoError(t, json.Unmarshal([]byte(trafficStatusRaw), &trafficStatus))

    assert.Len(t, trafficStatus, 2, "Should have 2 traffic targets")

    // Verify traffic split percentages
    totalPercent := 0
    for _, traffic := range trafficStatus {
        percent, ok := traffic["percent"].(float64)
        require.True(t, ok, "Percent should be a number")
        totalPercent += int(percent)
    }
    assert.Equal(t, 100, totalPercent, "Total traffic should be 100%")
}

// Test Cloud Run with IAM bindings
func TestCloudRunIAMBindings(t *testing.T) {
    t.Parallel()

    uniqueID := strings.ToLower(random.UniqueId())
    serviceName := fmt.Sprintf("test-cr-iam-%s", uniqueID)
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    testDir := test_structure.CopyTerraformFolderToTemp(t, "../", "test")

    // Test service account
    testServiceAccount := fmt.Sprintf("test-sa-%s@%s.iam.gserviceaccount.com", uniqueID, projectID)

    terraformOptions := &terraform.Options{
        TerraformDir: testDir,
        Vars: map[string]interface{}{
            "project_id":   projectID,
            "service_name": serviceName,
            "location":     "us-central1",
            "invokers": []string{
                "allUsers",
                fmt.Sprintf("serviceAccount:%s", testServiceAccount),
            },
            "admins": []string{
                fmt.Sprintf("user:admin@%s.com", projectID),
            },
            "developers": []string{
                fmt.Sprintf("user:dev@%s.com", projectID),
            },
            "custom_iam_bindings": []map[string]interface{}{
                {
                    "role":   "roles/run.viewer",
                    "member": fmt.Sprintf("user:viewer@%s.com", projectID),
                },
            },
        },
        NoColor: true,
    }

    defer terraform.Destroy(t, terraformOptions)

    terraform.InitAndApply(t, terraformOptions)

    // Validate IAM outputs
    invokers := terraform.OutputList(t, terraformOptions, "invoker_members")
    admins := terraform.OutputList(t, terraformOptions, "admin_members")
    developers := terraform.OutputList(t, terraformOptions, "developer_members")

    assert.Contains(t, invokers, "allUsers", "Should have allUsers as invoker")
    assert.Contains(t, invokers, fmt.Sprintf("serviceAccount:%s", testServiceAccount), "Should have service account as invoker")
    assert.Len(t, admins, 1, "Should have one admin")
    assert.Len(t, developers, 1, "Should have one developer")
}

// Test Cloud Run with VPC connector
func TestCloudRunWithVPCConnector(t *testing.T) {
    t.Parallel()

    uniqueID := strings.ToLower(random.UniqueId())
    serviceName := fmt.Sprintf("test-cr-vpc-%s", uniqueID)
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    testDir := test_structure.CopyTerraformFolderToTemp(t, "../", "test")

    terraformOptions := &terraform.Options{
        TerraformDir: testDir,
        Vars: map[string]interface{}{
            "project_id":          projectID,
            "service_name":        serviceName,
            "location":            "us-central1",
            "ingress_settings":    "internal-and-cloud-load-balancing",
            "vpc_connector_name":  fmt.Sprintf("test-connector-%s", uniqueID),
            "vpc_egress_settings": "all-traffic",
        },
        NoColor: true,
    }

    defer terraform.Destroy(t, terraformOptions)

    terraform.InitAndApply(t, terraformOptions)

    // Validate networking configuration
    ingressSettings := terraform.Output(t, terraformOptions, "ingress_settings")
    assert.Equal(t, "internal-and-cloud-load-balancing", ingressSettings, "Ingress should be restricted")
}

// Test Cloud Run with autoscaling configuration
func TestCloudRunAutoscaling(t *testing.T) {
    t.Parallel()

    uniqueID := strings.ToLower(random.UniqueId())
    serviceName := fmt.Sprintf("test-cr-scale-%s", uniqueID)
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    testDir := test_structure.CopyTerraformFolderToTemp(t, "../", "test")

    minInstances := 2
    maxInstances := 50

    terraformOptions := &terraform.Options{
        TerraformDir: testDir,
        Vars: map[string]interface{}{
            "project_id":            projectID,
            "service_name":          serviceName,
            "location":              "us-central1",
            "min_instances":         minInstances,
            "max_instances":         maxInstances,
            "container_concurrency": 100,
            "cpu_limit":             "2",
            "memory_limit":          "1Gi",
        },
        NoColor: true,
    }

    defer terraform.Destroy(t, terraformOptions)

    terraform.InitAndApply(t, terraformOptions)

    // Validate autoscaling configuration
    actualMinInstances := terraform.Output(t, terraformOptions, "min_instances")
    actualMaxInstances := terraform.Output(t, terraformOptions, "max_instances")

    assert.Equal(t, fmt.Sprintf("%d", minInstances), actualMinInstances, "Min instances should match")
    assert.Equal(t, fmt.Sprintf("%d", maxInstances), actualMaxInstances, "Max instances should match")
}

// Helper function to wait for service to be ready
func waitForServiceReady(t *testing.T, terraformOptions *terraform.Options, maxRetries int) {
    for i := 0; i < maxRetries; i++ {
        validationStatus := terraform.Output(t, terraformOptions, "module_validation_status")
        if validationStatus == "PASSED" {
            return
        }
        time.Sleep(10 * time.Second)
    }
    t.Fatal("Service did not become ready in time")
}