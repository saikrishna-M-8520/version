package test

import (
    "context"
    "fmt"
    "os"
    "path/filepath"
    "strings"
    "testing"
    "time"

    "cloud.google.com/go/storage"
    "github.com/gruntwork-io/terratest/modules/gcp"
    "github.com/gruntwork-io/terratest/modules/random"
    "github.com/gruntwork-io/terratest/modules/terraform"
    test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
    "github.com/stretchr/testify/assert"
    "github.com/stretchr/testify/require"
    "google.golang.org/api/iterator"
    "google.golang.org/api/option"
)

// Test constants
const (
    testRegion           = "us-central1"
    testStorageClass     = "STANDARD"
    testEnvironment      = "test"
    retryMaxAttempts     = 30
    timeBetweenRetries   = 10 * time.Second
)

// TestGCSBucketModule tests the GCS bucket module
func TestGCSBucketModule(t *testing.T) {
    t.Parallel()

    // Generate unique identifiers
    uniqueID := strings.ToLower(random.UniqueId())
    bucketName := fmt.Sprintf("test-gcs-%s", uniqueID)
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    // Define the module path
    modulePath := test_structure.CopyTerraformFolderToTemp(t, "../", ".")
    testPath := filepath.Join(modulePath, "test")

    // Terraform options
    terraformOptions := &terraform.Options{
        TerraformDir: testPath,
        Vars: map[string]interface{}{
            "project_id":                      projectID,
            "bucket_name":                     bucketName,
            "region":                          testRegion,
            "environment":                     testEnvironment,
            "storage_class":                   testStorageClass,
            "versioning_enabled":              true,
            "public_access_prevention":        "enforced",
            "uniform_bucket_level_access":     true,
            "force_destroy":                   true,
            "soft_delete_retention_duration":  604800,
            "monitoring_alert_enabled":        false,
            "turbo_replication_enabled":       false,
            "audit_logging_enabled":           false,
            "hierarchical_namespace_enabled":  false,
            "autoclass_enabled":               false,
            "encryption_key_name":             nil,
            "retention_policy":                nil,
            "lifecycle_rules":                 []interface{}{},
            "cors_rules":                      []interface{}{},
            "website_config":                  nil,
            "logging_config":                  nil,
            "iam_bindings":                    map[string]interface{}{},
            "vpc_sc_perimeter_name":           nil,
            "vpc_sc_access_policy":            nil,
            "vpc_sc_resources":                []interface{}{},
            "vpc_sc_restricted_services":      []interface{}{},
            "vpc_sc_ingress_policies":         []interface{}{},
            "vpc_sc_egress_policies":          []interface{}{},
            "cross_region_replication":        nil,
            "regional_replication":            nil,
            "aws_s3_transfer":                 nil,
            "azure_blob_transfer":             nil,
            "http_transfer":                   nil,
            "posix_transfer":                  nil,
            "monitoring_notification_channels": []interface{}{},
            "audit_log_exempted_members":      []interface{}{},
            "labels": map[string]interface{}{
                "test": "terratest",
            },
            "requester_pays": false,
        },
        NoColor: true,
    }

    // Ensure cleanup
    defer terraform.Destroy(t, terraformOptions)

    // Deploy the module
    terraform.InitAndApply(t, terraformOptions)

    // Run tests
    t.Run("BucketCreation", func(t *testing.T) {
        testBucketCreation(t, terraformOptions, bucketName, projectID)
    })

    t.Run("BucketConfiguration", func(t *testing.T) {
        testBucketConfiguration(t, terraformOptions, bucketName, projectID)
    })

    t.Run("BucketSecurity", func(t *testing.T) {
        testBucketSecurity(t, terraformOptions, bucketName, projectID)
    })

    t.Run("BucketLifecycle", func(t *testing.T) {
        testBucketLifecycle(t, terraformOptions, bucketName, projectID)
    })

    t.Run("BucketReplication", func(t *testing.T) {
        testBucketReplication(t, terraformOptions, bucketName, projectID)
    })
}

// testBucketCreation verifies the bucket was created successfully
func testBucketCreation(t *testing.T, terraformOptions *terraform.Options, bucketName, projectID string) {
    // Get outputs
    actualBucketName := terraform.Output(t, terraformOptions, "bucket_name")
    actualBucketURL := terraform.Output(t, terraformOptions, "bucket_url")
    actualBucketLocation := terraform.Output(t, terraformOptions, "bucket_location")
    actualBucketStorageClass := terraform.Output(t, terraformOptions, "bucket_storage_class")

    // Verify outputs
    assert.Equal(t, bucketName, actualBucketName)
    assert.Contains(t, actualBucketURL, bucketName)
    assert.Equal(t, testRegion, actualBucketLocation)
    assert.Equal(t, testStorageClass, actualBucketStorageClass)

    // Verify bucket exists in GCP
    ctx := context.Background()
    client, err := storage.NewClient(ctx)
    require.NoError(t, err)
    defer client.Close()

    bucket := client.Bucket(bucketName)
    attrs, err := bucket.Attrs(ctx)
    require.NoError(t, err)
    assert.Equal(t, bucketName, attrs.Name)
    assert.Equal(t, projectID, attrs.ProjectNumber)
}

// testBucketConfiguration verifies bucket configuration settings
func testBucketConfiguration(t *testing.T, terraformOptions *terraform.Options, bucketName, projectID string) {
    ctx := context.Background()
    client, err := storage.NewClient(ctx)
    require.NoError(t, err)
    defer client.Close()

    bucket := client.Bucket(bucketName)
    attrs, err := bucket.Attrs(ctx)
    require.NoError(t, err)

    // Test versioning
    assert.True(t, attrs.VersioningEnabled, "Versioning should be enabled")

    // Test storage class
    assert.Equal(t, testStorageClass, attrs.StorageClass, "Storage class should match")

    // Test labels
    assert.Contains(t, attrs.Labels, "test", "Should contain test label")
    assert.Equal(t, "terratest", attrs.Labels["test"], "Test label value should match")
    assert.Contains(t, attrs.Labels, "managed_by", "Should contain managed_by label")
    assert.Equal(t, "terraform", attrs.Labels["managed_by"], "managed_by label should be terraform")

    // Test soft delete policy
    assert.NotNil(t, attrs.SoftDeletePolicy, "Soft delete policy should be configured")
    if attrs.SoftDeletePolicy != nil {
        expectedDuration := 7 * 24 * time.Hour // 7 days
        assert.Equal(t, expectedDuration, attrs.SoftDeletePolicy.RetentionDuration, "Soft delete retention should be 7 days")
    }
}

// testBucketSecurity verifies security settings
func testBucketSecurity(t *testing.T, terraformOptions *terraform.Options, bucketName, projectID string) {
    ctx := context.Background()
    client, err := storage.NewClient(ctx)
    require.NoError(t, err)
    defer client.Close()

    bucket := client.Bucket(bucketName)
    attrs, err := bucket.Attrs(ctx)
    require.NoError(t, err)

    // Test public access prevention
    assert.Equal(t, storage.PublicAccessPreventionEnforced, attrs.PublicAccessPrevention, "Public access should be prevented")

    // Test uniform bucket-level access
    assert.True(t, attrs.UniformBucketLevelAccess.Enabled, "Uniform bucket-level access should be enabled")

    // Test requester pays
    assert.False(t, attrs.RequesterPays, "Requester pays should be disabled")
}

// testBucketLifecycle tests lifecycle rules functionality
func testBucketLifecycle(t *testing.T, terraformOptions *terraform.Options, bucketName, projectID string) {
    // Update terraform options to include lifecycle rules
    terraformOptionsWithLifecycle := &terraform.Options{
        TerraformDir: terraformOptions.TerraformDir,
        Vars: map[string]interface{}{
            "project_id":                      projectID,
            "bucket_name":                     bucketName,
            "region":                          testRegion,
            "environment":                     testEnvironment,
            "storage_class":                   testStorageClass,
            "versioning_enabled":              true,
            "public_access_prevention":        "enforced",
            "uniform_bucket_level_access":     true,
            "force_destroy":                   true,
            "soft_delete_retention_duration":  604800,
            "monitoring_alert_enabled":        false,
            "turbo_replication_enabled":       false,
            "audit_logging_enabled":           false,
            "hierarchical_namespace_enabled":  false,
            "autoclass_enabled":               false,
            "encryption_key_name":             nil,
            "retention_policy":                nil,
            "lifecycle_rules": []interface{}{
                map[string]interface{}{
                    "action": map[string]interface{}{
                        "type":          "SetStorageClass",
                        "storage_class": "NEARLINE",
                    },
                    "condition": map[string]interface{}{
                        "age":                   30,
                        "matches_storage_class": []string{"STANDARD"},
                    },
                },
                map[string]interface{}{
                    "action": map[string]interface{}{
                        "type": "Delete",
                    },
                    "condition": map[string]interface{}{
                        "age": 365,
                    },
                },
            },
            "cors_rules":                      []interface{}{},
            "website_config":                  nil,
            "logging_config":                  nil,
            "iam_bindings":                    map[string]interface{}{},
            "vpc_sc_perimeter_name":           nil,
            "vpc_sc_access_policy":            nil,
            "vpc_sc_resources":                []interface{}{},
            "vpc_sc_restricted_services":      []interface{}{},
            "vpc_sc_ingress_policies":         []interface{}{},
            "vpc_sc_egress_policies":          []interface{}{},
            "cross_region_replication":        nil,
            "regional_replication":            nil,
            "aws_s3_transfer":                 nil,
            "azure_blob_transfer":             nil,
            "http_transfer":                   nil,
            "posix_transfer":                  nil,
            "monitoring_notification_channels": []interface{}{},
            "audit_log_exempted_members":      []interface{}{},
            "labels": map[string]interface{}{
                "test": "terratest",
            },
            "requester_pays": false,
        },
        NoColor: true,
    }

    // Apply with lifecycle rules
    terraform.Apply(t, terraformOptionsWithLifecycle)

    // Verify lifecycle rules
    ctx := context.Background()
    client, err := storage.NewClient(ctx)
    require.NoError(t, err)
    defer client.Close()

    bucket := client.Bucket(bucketName)
    attrs, err := bucket.Attrs(ctx)
    require.NoError(t, err)

    assert.Len(t, attrs.Lifecycle.Rules, 2, "Should have 2 lifecycle rules")
}

// testBucketReplication tests replication configuration
func testBucketReplication(t *testing.T, terraformOptions *terraform.Options, bucketName, projectID string) {
    // Create destination bucket for testing replication
    destinationBucketName := fmt.Sprintf("%s-replica", bucketName)
    
    ctx := context.Background()
    client, err := storage.NewClient(ctx)
    require.NoError(t, err)
    defer client.Close()

    // Create destination bucket
    destinationBucket := client.Bucket(destinationBucketName)
    err = destinationBucket.Create(ctx, projectID, &storage.BucketAttrs{
        Location:     "us-east1",
        StorageClass: testStorageClass,
    })
    if err != nil && !strings.Contains(err.Error(), "already exists") {
        require.NoError(t, err)
    }
    defer destinationBucket.Delete(ctx)

    // Test turbo replication configuration
    terraformOptionsWithReplication := &terraform.Options{
        TerraformDir: terraformOptions.TerraformDir,
        Vars: map[string]interface{}{
            "project_id":                         projectID,
            "bucket_name":                        bucketName,
            "region":                             testRegion,
            "environment":                        testEnvironment,
            "storage_class":                      testStorageClass,
            "versioning_enabled":                 true,
            "public_access_prevention":           "enforced",
            "uniform_bucket_level_access":        true,
            "force_destroy":                      true,
            "soft_delete_retention_duration":     604800,
            "monitoring_alert_enabled":           false,
            "turbo_replication_enabled":          true,
            "turbo_replication_destination_bucket": destinationBucketName,
            "turbo_replication_max_instances":    10,
            "audit_logging_enabled":              false,
            "hierarchical_namespace_enabled":     false,
            "autoclass_enabled":                  false,
            "encryption_key_name":                nil,
            "retention_policy":                   nil,
            "lifecycle_rules":                    []interface{}{},
            "cors_rules":                         []interface{}{},
            "website_config":                     nil,
            "logging_config":                     nil,
            "iam_bindings":                       map[string]interface{}{},
            "vpc_sc_perimeter_name":              nil,
            "vpc_sc_access_policy":               nil,
            "vpc_sc_resources":                   []interface{}{},
            "vpc_sc_restricted_services":         []interface{}{},
            "vpc_sc_ingress_policies":            []interface{}{},
            "vpc_sc_egress_policies":             []interface{}{},
            "cross_region_replication":           nil,
            "regional_replication":               nil,
            "aws_s3_transfer":                    nil,
            "azure_blob_transfer":                nil,
            "http_transfer":                      nil,
            "posix_transfer":                     nil,
            "monitoring_notification_channels":   []interface{}{},
            "audit_log_exempted_members":         []interface{}{},
            "labels": map[string]interface{}{
                "test": "terratest",
            },
            "requester_pays": false,
        },
        NoColor: true,
    }

    // Apply with replication
    terraform.Apply(t, terraformOptionsWithReplication)

    // Verify turbo replication outputs
    turboReplicationTopic := terraform.Output(t, terraformOptionsWithReplication, "turbo_replication_topic")
    turboReplicationFunction := terraform.Output(t, terraformOptionsWithReplication, "turbo_replication_function")
    turboReplicationSA := terraform.Output(t, terraformOptionsWithReplication, "turbo_replication_service_account")

    assert.NotEmpty(t, turboReplicationTopic, "Turbo replication topic should be created")
    assert.NotEmpty(t, turboReplicationFunction, "Turbo replication function should be created")
    assert.NotEmpty(t, turboReplicationSA, "Turbo replication service account should be created")
}

// TestGCSBucketModuleWithCMEK tests the module with CMEK encryption
func TestGCSBucketModuleWithCMEK(t *testing.T) {
    t.Parallel()

    // Skip if KMS key is not available
    kmsKeyName := os.Getenv("TEST_KMS_KEY_NAME")
    if kmsKeyName == "" {
        t.Skip("Skipping CMEK test: TEST_KMS_KEY_NAME environment variable not set")
    }

    // Generate unique identifiers
    uniqueID := strings.ToLower(random.UniqueId())
    bucketName := fmt.Sprintf("test-gcs-cmek-%s", uniqueID)
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    // Define the module path
    modulePath := test_structure.CopyTerraformFolderToTemp(t, "../", ".")
    testPath := filepath.Join(modulePath, "test")

    // Terraform options with CMEK
    terraformOptions := &terraform.Options{
        TerraformDir: testPath,
        Vars: map[string]interface{}{
            "project_id":                      projectID,
            "bucket_name":                     bucketName,
            "region":                          testRegion,
            "environment":                     testEnvironment,
            "storage_class":                   testStorageClass,
            "versioning_enabled":              true,
            "public_access_prevention":        "enforced",
            "uniform_bucket_level_access":     true,
            "force_destroy":                   true,
            "encryption_key_name":             kmsKeyName,
            "soft_delete_retention_duration":  604800,
            "monitoring_alert_enabled":        false,
            "turbo_replication_enabled":       false,
            "audit_logging_enabled":           false,
            "hierarchical_namespace_enabled":  false,
            "autoclass_enabled":               false,
            "retention_policy":                nil,
            "lifecycle_rules":                 []interface{}{},
            "cors_rules":                      []interface{}{},
            "website_config":                  nil,
            "logging_config":                  nil,
            "iam_bindings":                    map[string]interface{}{},
            "vpc_sc_perimeter_name":           nil,
            "vpc_sc_access_policy":            nil,
            "vpc_sc_resources":                []interface{}{},
            "vpc_sc_restricted_services":      []interface{}{},
            "vpc_sc_ingress_policies":         []interface{}{},
            "vpc_sc_egress_policies":          []interface{}{},
            "cross_region_replication":        nil,
            "regional_replication":            nil,
            "aws_s3_transfer":                 nil,
            "azure_blob_transfer":             nil,
            "http_transfer":                   nil,
            "posix_transfer":                  nil,
            "monitoring_notification_channels": []interface{}{},
            "audit_log_exempted_members":      []interface{}{},
            "labels": map[string]interface{}{
                "test": "terratest-cmek",
            },
            "requester_pays": false,
        },
        NoColor: true,
    }

    // Ensure cleanup
    defer terraform.Destroy(t, terraformOptions)

    // Deploy the module
    terraform.InitAndApply(t, terraformOptions)

    // Verify CMEK encryption
    ctx := context.Background()
    client, err := storage.NewClient(ctx)
    require.NoError(t, err)
    defer client.Close()

    bucket := client.Bucket(bucketName)
    attrs, err := bucket.Attrs(ctx)
    require.NoError(t, err)

    assert.NotNil(t, attrs.Encryption, "Encryption should be configured")
    assert.Equal(t, kmsKeyName, attrs.Encryption.DefaultKMSKeyName, "KMS key should match")
}

// TestGCSBucketModuleWithWebsite tests static website hosting configuration
func TestGCSBucketModuleWithWebsite(t *testing.T) {
    t.Parallel()

    // Generate unique identifiers
    uniqueID := strings.ToLower(random.UniqueId())
    bucketName := fmt.Sprintf("test-gcs-website-%s", uniqueID)
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    // Define the module path
    modulePath := test_structure.CopyTerraformFolderToTemp(t, "../", ".")
    testPath := filepath.Join(modulePath, "test")

    // Terraform options with website configuration
    terraformOptions := &terraform.Options{
        TerraformDir: testPath,
        Vars: map[string]interface{}{
            "project_id":                     projectID,
            "bucket_name":                    bucketName,
            "region":                         testRegion,
            "environment":                    testEnvironment,
            "storage_class":                  testStorageClass,
            "versioning_enabled":             true,
            "public_access_prevention":       "inherited",
            "uniform_bucket_level_access":    false,
            "force_destroy":                  true,
            "soft_delete_retention_duration": 604800,
            "website_config": map[string]interface{}{
                "main_page_suffix": "index.html",
                "not_found_page":   "404.html",
            },
            "cors_rules": []interface{}{
                map[string]interface{}{
                    "origin":          []string{"https://example.com", "https://test.com"},
                    "method":          []string{"GET", "HEAD", "PUT", "POST", "DELETE"},
                    "response_header": []string{"*"},
                    "max_age_seconds": 3600,
                },
            },
            "monitoring_alert_enabled":        false,
            "turbo_replication_enabled":       false,
            "audit_logging_enabled":           false,
            "hierarchical_namespace_enabled":  false,
            "autoclass_enabled":               false,
            "encryption_key_name":             nil,
            "retention_policy":                nil,
            "lifecycle_rules":                 []interface{}{},
            "logging_config":                  nil,
            "iam_bindings":                    map[string]interface{}{},
            "vpc_sc_perimeter_name":           nil,
            "vpc_sc_access_policy":            nil,
            "vpc_sc_resources":                []interface{}{},
            "vpc_sc_restricted_services":      []interface{}{},
            "vpc_sc_ingress_policies":         []interface{}{},
            "vpc_sc_egress_policies":          []interface{}{},
            "cross_region_replication":        nil,
            "regional_replication":            nil,
            "aws_s3_transfer":                 nil,
            "azure_blob_transfer":             nil,
            "http_transfer":                   nil,
            "posix_transfer":                  nil,
            "monitoring_notification_channels": []interface{}{},
            "audit_log_exempted_members":      []interface{}{},
            "labels": map[string]interface{}{
                "test": "terratest-website",
            },
            "requester_pays": false,
        },
        NoColor: true,
    }

    // Ensure cleanup
    defer terraform.Destroy(t, terraformOptions)

    // Deploy the module
    terraform.InitAndApply(t, terraformOptions)

    // Verify website configuration
    ctx := context.Background()
    client, err := storage.NewClient(ctx)
    require.NoError(t, err)
    defer client.Close()

    bucket := client.Bucket(bucketName)
    attrs, err := bucket.Attrs(ctx)
    require.NoError(t, err)

    // Test website configuration
    assert.NotNil(t, attrs.Website, "Website configuration should be set")
    assert.Equal(t, "index.html", attrs.Website.MainPageSuffix, "Main page suffix should be index.html")
    assert.Equal(t, "404.html", attrs.Website.NotFoundPage, "Not found page should be 404.html")

    // Test CORS configuration
    assert.Len(t, attrs.CORS, 1, "Should have 1 CORS rule")
    if len(attrs.CORS) > 0 {
        cors := attrs.CORS[0]
        assert.Contains(t, cors.Origins, "https://example.com", "CORS origins should contain example.com")
        assert.Contains(t, cors.Origins, "https://test.com", "CORS origins should contain test.com")
        assert.Contains(t, cors.Methods, "GET", "CORS methods should contain GET")
        assert.Contains(t, cors.Methods, "POST", "CORS methods should contain POST")
        assert.Equal(t, 3600, cors.MaxAge, "CORS max age should be 3600")
    }
}

// Helper function to check if a bucket exists
func bucketExists(t *testing.T, client *storage.Client, bucketName string) bool {
    ctx := context.Background()
    bucket := client.Bucket(bucketName)
    _, err := bucket.Attrs(ctx)
    return err == nil
}

// Helper function to list objects in a bucket
func listBucketObjects(t *testing.T, client *storage.Client, bucketName string) []string {
    ctx := context.Background()
    bucket := client.Bucket(bucketName)
    
    var objects []string
    it := bucket.Objects(ctx, nil)
    for {
        attrs, err := it.Next()
        if err == iterator.Done {
            break
        }
        require.NoError(t, err)
        objects = append(objects, attrs.Name)
    }
    
    return objects
}